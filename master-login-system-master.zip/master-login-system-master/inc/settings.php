<?php

// Master Login System
// Mihai Ionut Vilcu (ionutvmi@gmail.com)
// configuration file


// database details
$set->db_host = 'localhost'; // database host
$set->db_user = 'root'; // database user
$set->db_pass = ''; // database password
$set->db_name = 'mls'; // database name

define('MLS_PREFIX', 'mls_');  
